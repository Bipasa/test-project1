/**
 * Pojos for <a href="https://agileguru.atlassian.net/browse/PDM-3">PDM-3</a>
 * @author Marco Tedone
 *
 */
package uk.co.jemos.podam.test.dto.pdm3;